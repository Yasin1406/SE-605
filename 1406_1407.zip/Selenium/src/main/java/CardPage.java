import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.Duration;

public class CardPage {
    private static final Logger logger = LoggerFactory.getLogger(CardPage.class);
    private final WebDriver driver;
    private final WebDriverWait wait;

    // Locators
    private final By addNewCardLink = By.linkText("Add a new card...");
    private final By cardNameInput = By.id("card_name");
    private final By newCardForm = By.id("new_card_form");
    private final By cardSubmitButton = By.cssSelector("button[type='submit']");
    private final By cardNameDisplay = By.cssSelector(".card-content > span");

    public CardPage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(10));
    }

    public void clickAddNewCard() {
        logger.info("Clicking add new card link");
        WebElement link = wait.until(ExpectedConditions.elementToBeClickable(addNewCardLink));
        link.click();
        logger.info("Clicked add new card link");
    }

    public void enterCardName(String cardName) {
        logger.info("Entering card name '{}'", cardName);
        WebElement input = wait.until(ExpectedConditions.visibilityOfElementLocated(cardNameInput));
        input.clear();
        input.sendKeys(cardName);
        logger.info("Entered card name '{}'", cardName);
    }

    public void clickNewCardForm() {
        logger.info("Clicking new card form");
        WebElement form = wait.until(ExpectedConditions.elementToBeClickable(newCardForm));
        form.click();
        logger.info("Clicked new card form");
    }

    public void clickSubmitButton() {
        logger.info("Clicking submit button");
        logger.info("Page source before submit: {}", driver.getPageSource());
        WebElement button = wait.until(ExpectedConditions.elementToBeClickable(cardSubmitButton));
        button.click();
        logger.info("Clicked submit button");
    }

    public String getCardNameDisplay() {
        logger.info("Retrieving displayed card name");
        WebElement element = wait.until(ExpectedConditions.visibilityOfElementLocated(cardNameDisplay));
        String text = element.getText();
        logger.info("Retrieved displayed card name: '{}'", text);
        return text;
    }

    public String getPageSourceOnError() {
        logger.info("Retrieving page source for debugging");
        return driver.getPageSource();
    }
}