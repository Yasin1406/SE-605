import io.github.bonigarcia.wdm.WebDriverManager;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.Duration;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;

public class CardPageTest {
    private static final Logger logger = LoggerFactory.getLogger(CardPageTest.class);
    private WebDriver driver;
    private BoardPage boardPage;
    private ListPage listPage;
    private CardPage cardPage;

    @Before
    public void setUp() {
        WebDriverManager.firefoxdriver().driverVersion("0.36.0").setup();
        FirefoxOptions options = new FirefoxOptions();
        options.setBinary("/usr/bin/firefox-esr");
        driver = new FirefoxDriver(options);
        driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(30));
        driver.manage().window().setSize(new Dimension(960, 1012));
        boardPage = new BoardPage(driver);
        listPage = new ListPage(driver);
        cardPage = new CardPage(driver);
        logger.info("WebDriver, BoardPage, ListPage, and CardPage initialized successfully");
    }

    @After
    public void tearDown() {
        if (driver != null) {
            driver.quit();
            logger.info("WebDriver closed");
        }
    }

    private void performLogin() {
        boardPage.navigateToSignIn();
        boardPage.enterEmail("john@phoenix-trello.com");
        boardPage.enterPassword("12345678");
        boardPage.clickLoginButton();
    }

    private void createBoard() {
        boardPage.clickAddNewBoard();
        boardPage.enterBoardName("Mohammed");
        boardPage.submitBoardForm();
    }

    private void createList() {
        listPage.clickListInnerContainer();
        listPage.enterListName("Yasin");
        listPage.clickSubmitButton();
    }

    @Test
    public void testCreateCard() {
        try {
            performLogin();
            createBoard();
            createList();
            cardPage.clickAddNewCard();
            cardPage.enterCardName("1406");
            cardPage.clickNewCardForm();
            cardPage.clickSubmitButton();
            assertThat(cardPage.getCardNameDisplay(), is("1406"));
            logger.info("testCreateCard completed successfully");
        } catch (Exception e) {
            logger.error("testCreateCard failed due to: {}. Page source: {}", e.getMessage(), cardPage.getPageSourceOnError(), e);
            throw e;
        }
    }
}