import io.github.bonigarcia.wdm.WebDriverManager;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.Duration;

import static org.junit.Assert.assertEquals;

public class BoardPageTest {
    private static final Logger logger = LoggerFactory.getLogger(BoardPageTest.class);
    private WebDriver driver;
    private BoardPage boardPage;

    @Before
    public void setUp() {
        WebDriverManager.firefoxdriver().driverVersion("0.36.0").setup();
        FirefoxOptions options = new FirefoxOptions();
        options.setBinary("/usr/bin/firefox-esr");
        driver = new FirefoxDriver(options);
        driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(30));
        driver.manage().window().setSize(new Dimension(960, 1012));
        boardPage = new BoardPage(driver);
        logger.info("WebDriver and BoardPage initialized successfully");
    }

    @After
    public void tearDown() {
        if (driver != null) {
            driver.quit();
            logger.info("WebDriver closed");
        }
    }

    private void performLogin() {
        boardPage.navigateToSignIn();
        boardPage.enterEmail("john@phoenix-trello.com");
        boardPage.enterPassword("12345678");
        boardPage.clickLoginButton();
    }

    @Test
    public void testCreateBoard() {
        try {
            performLogin();
            boardPage.clickAddNewBoard();
            boardPage.enterBoardName("Mohammed");
            boardPage.submitBoardForm();
            assertEquals("Mohammed", boardPage.getBoardNameDisplay());
            logger.info("testCreateBoard completed successfully");
        } catch (Exception e) {
            logger.error("testCreateBoard failed due to: {}. Page source: {}", e.getMessage(), boardPage.getPageSourceOnError(), e);
            throw e;
        }
    }
}